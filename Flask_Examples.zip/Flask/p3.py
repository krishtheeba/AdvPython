from flask import Flask,redirect,url_for


app=Flask(__name__)

@app.route("/")
def f1():
	return "Home Page"

@app.route("/displaymessage")
def f2():
	return "<h1> This is a Display Page</h1>"


@app.route("/usr/<mydept>")
def f3(mydept):
	if mydept == "sales":
		return redirect(url_for('f2'))
	else:
		return redirect(url_for('f1'))
@app.route("/mydisplay/<py_var>")
def f4(py_var):
	return f"<h1> Your Input msg is :{py_var}</h1>"

@app.route("/dept/<mydept>")
def f5(mydept):
	return redirect(url_for('f4',py_var=mydept))
if __name__=="__main__":
	app.run(debug=True)