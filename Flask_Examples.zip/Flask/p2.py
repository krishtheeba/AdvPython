
from flask import Flask, render_template

app=Flask(__name__)

@app.route("/")
def f1():
	return render_template("a.html")

@app.route("/mypage")
def f2():
	myname="Theeba"
	return render_template("b.html",tName=myname)

@app.route("/mycity/<varCity>")   # 1
def f3(varCity): # 2
	return render_template("c.html",tCity=varCity) #3

@app.route("/contactus")
def f4():
	return render_template("d.html",tVar=[33323,2.33, "DATA1"])

if __name__=="__main__":
	app.run(debug=True)