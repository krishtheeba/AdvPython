import flask
       # flask - module

app=flask.Flask(__name__)    # predefined attr
#|    |      |----- Classname
#|   module name
#userdefined

@app.route("/")
def f1():
	return "<h1> Welcome </h1>"

@app.route("/AboutUs")
def f2():
	return "<h2> This is About Us Page </h2>"

@app.route("/MyCity")
def f3():
	return "<h1> City Name : Bengaluru </h1>"

@app.route("/MyDept")
def f4():
	return "<h2> Department : Production </h2>"
if __name__ == "__main__":
	app.run(debug=True)